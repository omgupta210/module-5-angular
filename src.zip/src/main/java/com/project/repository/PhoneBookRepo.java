package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.Model.Contact_Details;

@Repository
public interface PhoneBookRepo extends JpaRepository<Contact_Details, Integer> {

}
