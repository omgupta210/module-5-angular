import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'paren'
})
export class ParenPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
