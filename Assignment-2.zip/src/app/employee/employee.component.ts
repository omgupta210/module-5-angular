import { Component, OnInit } from '@angular/core';
import { debounce } from 'rxjs';
import { Employee } from './employee';

@Component({
  selector:'[app-employee,app-emp1]',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  public user:Employee[];
  constructor() {
    this.user=[];
    
   }
  
   public showedit:boolean[]=[];
   public initlializeduser()
   {
    this.user=[{
      employee_id:1,
      first_name:'om',
      last_name:'gupta',
      salary:50000,
      dob:new Date(),
      email:'omgupta@gmail.com',
      action:false
    },
    {
      employee_id:2,
      first_name:'Ramesh',
      last_name:'singh',
      salary:42000,
      dob:new Date(),
      email:'rameshsingh@gmail.com',
      action:false
    },
    {
      employee_id:1,
      first_name:'raj',
      last_name:'sinha',
      salary:20000,
      dob:new Date(),
      email:'raj@gmail.com',
      action:false
    }]

    for(let i=0;i<this.user.length;i++)
        this.showedit[i]=false;

   }
   
    
  ngOnInit(): void {
    this.initlializeduser();
    this.user[0].dob.setDate(23);
    this.user[0].dob.setMonth(11);
    this.user[0].dob.setFullYear(1998);
    
  }
  editEmp(i:number):void{
     this.showedit[i]=true;
  } 
  updateEmp(i:number):void{
            this.showedit[i]=false;
  }

}
