import { ParenPipe } from './paren.pipe';

describe('ParenPipe', () => {
  it('create an instance', () => {
    const pipe = new ParenPipe();
    expect(pipe).toBeTruthy();
  });
});
