package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Model.Contact_Details;
import com.project.service.PhonebookService;

@Controller
public class PhonebookController {
	
	@Autowired 
	private PhonebookService phoneservice;
	
	
	@GetMapping("home")
	public String getpage(Model model)
	{ model.addAttribute("listcontact",phoneservice.getdata());
		return "index";
	}
	
	
	@GetMapping("/")
	public String addcontact(Model model)
	{ 
		Contact_Details c1=new Contact_Details();
		model.addAttribute("listcontact1",c1);
		return "Home";
	}
	
	/*
	@DeleteMapping("/deleteEmployee/{id}")
    public String deleteThroughId(@PathVariable(value = "id") Integer id) {
        phoneservice.deleteViaId(id);
        return "redirect:/";
	}*/
	 @PostMapping("/save")
	    public String saveContact(@ModelAttribute("listcontact2") Contact_Details contact) {
		 phoneservice.save(contact);
	        return "index";
	    }

}
