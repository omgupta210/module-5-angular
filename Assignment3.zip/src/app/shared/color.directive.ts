import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appColor]'
})
export class ColorDirective {

  @HostListener('mouseover') applymouseover()
  {
    this.changecolor("lightgreen");
  }
  @HostListener('mouseleave') applymouseleave()
  {
    this.changecolor("white")
  }
  constructor(private elemnetref:ElementRef) { }
  public changecolor(highlightcolor:string)
  {
    this.elemnetref.nativeElement.style.backgroundColor=highlightcolor;

  }
}
