import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value:string, condition?:boolean): string {
    if(value===' ')
      { return '';}
    if(condition)
    {
      return '(('+value+'))';

    }
  
  
    return '('+value+')';
  

  }

}
