package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.AuthenticationRequest;
import com.example.demo.models.AuthenticationResponse;
import com.example.demo.utils.JWTUtils;

@RestController
public class HelloWorldController {
	
	@Autowired
	private AuthenticationManager aumanager;
	
	@Autowired
	private MyUserDetailsService UserDetailsService;
	
	@Autowired
	private JWTUtils jwttokenutil;
	
	@GetMapping({"/","hello"})
	public String hello()
	{
		return "Hellow World!!!";
	}

	//@RequestMapping(value="/authenticate" , method=RequestMethod.POST)
	@PostMapping("/authenticate")
		public 	ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticaterequest) throws Exception
		{
			try {
				
				aumanager.authenticate(new UsernamePasswordAuthenticationToken(authenticaterequest.getUsename(),authenticaterequest.getPassword()));
				
			}
			catch(BadCredentialsException e)
			{
				throw new Exception("Incorrect username and password",e);
			}
			
			final UserDetails userdetails=UserDetailsService.loadUserByUsername(authenticaterequest.getUsename());
			final String jwt=jwttokenutil.generateToken(userdetails);
			return ResponseEntity.ok(new AuthenticationResponse(jwt));
		}
	
}
