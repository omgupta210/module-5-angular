import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  
   prd1:Product[]=[];
  constructor(private prd:ProductService) {
    
   }

  ngOnInit(): void {
     this.prd1=this.prd.getdata();
  }


  onselect(department:number)
  {
    
  }
}
