export interface Employee2 {
    id:number;
    employee_name:string;
    employee_salary:string;
    employee_age:string;
    profile_image:string;
    
  
}
