import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee2 } from './employee2';

@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {

 
 //url:String="http://localhost:8080/data";
  constructor(private http:HttpClient) { 
 
  }

  public getdata():Observable<Employee2[]>{
    return this.http.get<Employee2[]>("http://dummy.restapiexample.com/api/v1/employees")
  }


}
