package com.project.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Contact_Details {
	
	@Id
	private int contact_id;
	private String contact_name;
	private String contact_email;
	private int contact_number;
	public int getContact_id() {
		return contact_id;
	}
	public void setContact_id(int contact_id) {
		this.contact_id = contact_id;
	}
	public String getContact_name() {
		return contact_name;
	}
	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}
	public String getContact_email() {
		return contact_email;
	}
	public void setContact_email(String contact_email) {
		this.contact_email = contact_email;
	}
	public int getContact_number() {
		return contact_number;
	}
	public void setContact_number(int contact_number) {
		this.contact_number = contact_number;
	}
	public Contact_Details(int contact_id, String contact_name, String contact_email, int contact_number) {
		super();
		this.contact_id = contact_id;
		this.contact_name = contact_name;
		this.contact_email = contact_email;
		this.contact_number = contact_number;
	}

	public Contact_Details() {
		System.out.println("Hi");
	
	}
	
	
}
