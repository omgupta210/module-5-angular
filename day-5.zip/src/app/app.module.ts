import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { Stocks1Component } from './components/stocks1/stocks1.component';
import { Stocks2Component } from './components/stocks2/stocks2.component';
import { Stocks3Component } from './components/stocks3/stocks3.component';
import { HighlightDirective } from './shared/highlight.directive';
import { ParenPipe } from './shared/paren.pipe';
import { SearchPipe } from './shared/search.pipe';

@NgModule({
  declarations: [
    AppComponent,
    Stocks1Component,
    Stocks2Component,
    Stocks3Component,
    HighlightDirective,
    ParenPipe,
    SearchPipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
