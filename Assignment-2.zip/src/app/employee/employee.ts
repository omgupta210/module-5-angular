export interface Employee {
    employee_id:Number;
    first_name:String;
    last_name:String;
    salary:Number;
    dob:Date;
    email:String;
    action:boolean;
}
