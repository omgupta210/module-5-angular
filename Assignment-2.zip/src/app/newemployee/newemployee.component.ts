import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs';
import { observable } from 'rxjs/internal/symbol/observable';
import { Employee2 } from '../employee2';
import { EmployeeserviceService } from '../employeeservice.service';

@Component({
  selector: 'app-newemployee',
  templateUrl: './newemployee.component.html',
  styleUrls: ['./newemployee.component.css']
})
export class NewemployeeComponent implements OnInit {

  public emp1:Employee2[];

  constructor(public employee:EmployeeserviceService) {
    this.emp1=[];
   
   }

  ngOnInit() { 
      this.employee.getdata().subscribe(response=>{
       
       //const data = response ;
        this.emp1=response;
        console.log(response);
        
        
      });
  }

}
