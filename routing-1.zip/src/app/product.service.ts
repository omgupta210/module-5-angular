import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private productlist:Product[];

  constructor() { 
    this.productlist=[];
  }

  public getdata(): Product[] 
  {
      return [
        {
          "name":"windows",
           "price":120
       },
       {
        "name":"apple",
        "price":30
      },
      {
        "name":"papaya",
         "price":80
      }

    ]
  }
}
