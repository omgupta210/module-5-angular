import { Component, OnInit } from '@angular/core';
import Employee from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {


  public emplist:Employee[];
  constructor() { 
    this.emplist=[];
    
    
  }

  ngOnInit(): void {
    this.initiliazedEmp();
    this.emplist[0].dob.setDate(12);
    this.emplist[1].dob.setDate(24);
    this.emplist[2].dob.setDate(6);
    this.emplist[3].dob.setDate(23);
    this.emplist[4].dob.setDate(11);
    this.emplist[0].dob.setMonth(3);
    this.emplist[1].dob.setMonth(24);
    this.emplist[2].dob.setMonth(6);
    this.emplist[3].dob.setMonth(7);
    this.emplist[4].dob.setMonth(11);
    
  }

 public initiliazedEmp(): void
  {
    this.emplist=[{
      employee_id:1,
      first_name:'om',
      last_name:'gupta',
      salary:50000,
      dob:new Date(),
      email:'omgupta@gmail.com',
      
    },
    {
      employee_id:2,
      first_name:'Ramesh',
      last_name:'singh',
      salary:42000,
      dob:new Date(),
      email:'rameshsingh@gmail.com',
     
    },
    {
      employee_id:4,
      first_name:'raj',
      last_name:'sinha',
      salary:20000,
      dob:new Date(),
      email:'raj@gmail.com',
     
    },
    {
      employee_id:10,
      first_name:'rinku',
      last_name:'apndey',
      salary:20000,
      dob:new Date(),
      email:'pandey@gmail.com',
     
    },
    {
      employee_id:12,
      first_name:'suraj',
      last_name:'kumar',
      salary:20000,
      dob:new Date(),
      email:'suraj@gmail.com',
      
    }]
  }


}
