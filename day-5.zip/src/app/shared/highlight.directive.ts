import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {
  @Input() highlightcolor:string|null;
  @HostListener('mouseover') applymouseover(){
    this.highlightcolor?this.changeColor(this.highlightcolor,'white'):this.changeColor('blue','white');
}
@HostListener('mouseleave')applymouseleave()
{
this.changeColor('white','grey');
}
constructor(private elementRef:ElementRef) { 
  this.highlightcolor=null;


}

public changeColor(bgcolor:string,fncolor:string){
   this.elementRef.nativeElement.style.backgroundColor=bgcolor;
   this.elementRef.nativeElement.style.color=fncolor;
}

}
