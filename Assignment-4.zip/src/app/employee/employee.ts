export default interface Employee{
    employee_id:number;
    first_name:string;
    last_name:string;
    salary:number;
    dob:Date;
    email:string;
    
}

